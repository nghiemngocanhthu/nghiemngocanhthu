package ntust.edu.tw.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;


public class BlueToothAdapter extends BaseAdapter {
    private Context context;
    private List<BlueToothBean> blueToothBeans;
    private OnItemClickLitener mOnItemClickLitener;

    public BlueToothAdapter(Context context, List<BlueToothBean> blueToothBeans) {
        this.context = context;
        this.blueToothBeans = blueToothBeans;
    }

    //設置回調接口
    public interface OnItemClickLitener{
        void onItemClick(View view, int position);
    }

    public void setOnItemClickLitener(OnItemClickLitener mOnItemClickLitener){
        this.mOnItemClickLitener = mOnItemClickLitener;
    }

    @Override
    public int getCount() {
        return blueToothBeans.size();
    }

    @Override
    public Object getItem(int i) {
        return blueToothBeans.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        final int postion=i;
        ViewHolder viewHolder = null;
        if (view == null) {
            viewHolder = new ViewHolder();
            view = LayoutInflater.from(context).inflate(R.layout.item_bluetooth, null);
            viewHolder.item_bluetooth_id = (TextView) view.findViewById(R.id.item_bluetooth_id);
            viewHolder.item_bluetooth_name = (TextView) view.findViewById(R.id.item_bluetooth_name);
            viewHolder.item_bluetooth_address = (TextView) view.findViewById(R.id.item_bluetooth_address);
            viewHolder.item_bluetooth_connect = (Button) view.findViewById(R.id.item_bluetooth_connect);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }
        viewHolder.item_bluetooth_id.setText(postion+1+"");
        viewHolder.item_bluetooth_name.setText(blueToothBeans.get(i).getBlueToothName());
        viewHolder.item_bluetooth_address.setText(blueToothBeans.get(i).getBlueToothAddress());
        //連接的監聽事件
        viewHolder.item_bluetooth_connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mOnItemClickLitener.onItemClick(view, postion);
            }
        });
        return view;
    }
    class ViewHolder {
        TextView item_bluetooth_id,item_bluetooth_name,item_bluetooth_address;
        Button item_bluetooth_connect;
    }
}