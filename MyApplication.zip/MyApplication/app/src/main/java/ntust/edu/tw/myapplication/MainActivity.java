package ntust.edu.tw.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    Button sousuo;
    ListView listview;
    BluetoothAdapter mBluetoothAdapter;
    List<BlueToothBean>blueToothBeans=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sousuo=(Button) findViewById(R.id.sousuo);
        listview=(ListView) findViewById(R.id.listview);
        mBluetoothAdapter=BluetoothAdapter.getDefaultAdapter();

        IntentFilter filter=new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(mReceiver,filter);
        IntentFilter filter2=new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        registerReceiver(mReceiver,filter2);
        sousuo.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.sousuo:
                if(!mBluetoothAdapter.isEnabled())
                {
                    mBluetoothAdapter.enable();

                }

                mBluetoothAdapter.startDiscovery();

                break;
        }
    }

    //定義廣播接收
    private BroadcastReceiver mReceiver=new BroadcastReceiver(){



        @Override
        public void onReceive(Context context, Intent intent) {
            String action=intent.getAction();
            Log.e("xzf", action);
            if(action.equals(BluetoothDevice.ACTION_FOUND))
            {
                BluetoothDevice device=intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

                BlueToothBean blueToothBean=new BlueToothBean(device.getName(),device.getAddress());

                //没有的時候直接添加
                if(blueToothBeans.size()==0){
                    blueToothBeans.add(blueToothBean);
                }else {
                    int judge=0;//0表示未添加到list的新設備，1表示已經掃描并添加到list的設備
                    for(int i=0;i<blueToothBeans.size();i++){
                        String address=blueToothBeans.get(i).getBlueToothAddress();
                        Log.i("mac_____address",address+"______________"+device.getAddress());
                        //如果相同設備已經添加則不添加
                        if(address.equals(blueToothBean.getBlueToothAddress())){
                            judge=1;
                            break;
                        }
                    }
                    if(judge==0){
                        blueToothBeans.add(blueToothBean);
                    }
                }
            }else if(action.equals(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)){
                final BlueToothAdapter adapter=new BlueToothAdapter(MainActivity.this,blueToothBeans);
                adapter.setOnItemClickLitener(new BlueToothAdapter.OnItemClickLitener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        Toast.makeText(MainActivity.this,blueToothBeans.get(position).getBlueToothAddress(),Toast.LENGTH_SHORT).show();
                    }
                });
                listview.setAdapter(adapter);
                Log.i("MainActivity藍牙","搜索完成");
            }
        }


    };
}