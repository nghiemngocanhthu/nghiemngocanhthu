
package hw.app.bluetooth.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private ViewPager mviewPager;
    Button button;
    ListView listview;
    BluetoothAdapter mBluetoothAdapter;
    List<BlueToothBean>blueToothBeans=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        View mTabLayout = findViewById(R.id.tab_layout);
        mviewPager = findViewById(R.id.view_pager);
        ViewPagerAdapter viewPagerAdapter = new viewPagerApdater(getSupportFragmentManager(), FragmentStatePagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        mviewPager.setAdapter(viewPagerAdapter);
        mTabLayout.setupWithViewPager(mviewPager);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button=(Button) findViewById(R.id.button);
        listview=(ListView) findViewById(R.id.listview);
        mBluetoothAdapter=BluetoothAdapter.getDefaultAdapter();

        IntentFilter filter=new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(mReceiver,filter);
        IntentFilter filter2=new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        registerReceiver(mReceiver,filter2);
        sousuo.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.button:
                if(!mBluetoothAdapter.isEnabled())
                {
                    mBluetoothAdapter.enable();

                }

                mBluetoothAdapter.startDiscovery();

                break;
        }
    }


    private BroadcastReceiver mReceiver=new BroadcastReceiver(){



        @Override
        public void onReceive(Context context, Intent intent) {
            String action=intent.getAction();
            Log.e("xzf", action);
            if(action.equals(BluetoothDevice.ACTION_FOUND))
            {
                BluetoothDevice device=intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

                BlueToothBean blueToothBean=new BlueToothBean(device.getName(),device.getAddress());

                if(blueToothBeans.size()==0){
                    blueToothBeans.add(blueToothBean);
                }else {
                    int judge=0;
                    for(int i=0;i<blueToothBeans.size();i++){
                        String address=blueToothBeans.get(i).getBlueToothAddress();
                        Log.i("mac_____address",address+"______________"+device.getAddress());
                        
                        if(address.equals(blueToothBean.getBlueToothAddress())){
                            judge=1;
                            break;
                        }
                    }
                    if(judge==0){
                        blueToothBeans.add(blueToothBean);
                    }
                }
            }else if(action.equals(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)){
                final BlueToothAdapter adapter=new BlueToothAdapter(MainActivity.this,blueToothBeans);
                adapter.setOnItemClickLitener(new BlueToothAdapter.OnItemClickLitener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        Toast.makeText(MainActivity.this,blueToothBeans.get(position).getBlueToothAddress(),Toast.LENGTH_SHORT).show();
                    }
                });
                listview.setAdapter(adapter);
                Log.i("MainActivity bluetooth","success");
            }
        }


    };
}